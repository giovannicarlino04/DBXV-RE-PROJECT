﻿namespace CharEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.cbZSoul = new System.Windows.Forms.ComboBox();
            this.txtPSCVal = new System.Windows.Forms.TextBox();
            this.txtPSCinfo = new System.Windows.Forms.TextBox();
            this.lstPSC = new System.Windows.Forms.ListView();
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.cbEva = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cbUlt2 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cbUlt1 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cbSuper4 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbSuper3 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbSuper2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbSuper1 = new System.Windows.Forms.ComboBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCSO4 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCSO3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCSO2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtCSO1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtCMS7 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCMS6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCMS5 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCMS4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCMS3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCMS2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCMS1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbCharacter = new System.Windows.Forms.ComboBox();
            this.cbCostumes = new System.Windows.Forms.ComboBox();
            this.lblChar = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 39);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(443, 368);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.cbZSoul);
            this.tabPage1.Controls.Add(this.txtPSCVal);
            this.tabPage1.Controls.Add(this.txtPSCinfo);
            this.tabPage1.Controls.Add(this.lstPSC);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(435, 342);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Stats";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(291, 306);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(138, 21);
            this.button4.TabIndex = 5;
            this.button4.Text = "Save PSC Changes";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(10, 307);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 17);
            this.label20.TabIndex = 4;
            this.label20.Text = "Z-Soul";
            // 
            // cbZSoul
            // 
            this.cbZSoul.FormattingEnabled = true;
            this.cbZSoul.Location = new System.Drawing.Point(66, 306);
            this.cbZSoul.Name = "cbZSoul";
            this.cbZSoul.Size = new System.Drawing.Size(219, 21);
            this.cbZSoul.TabIndex = 3;
            this.cbZSoul.SelectedIndexChanged += new System.EventHandler(this.cbZSoul_SelectedIndexChanged);
            // 
            // txtPSCVal
            // 
            this.txtPSCVal.Location = new System.Drawing.Point(214, 23);
            this.txtPSCVal.Name = "txtPSCVal";
            this.txtPSCVal.Size = new System.Drawing.Size(149, 20);
            this.txtPSCVal.TabIndex = 2;
            this.txtPSCVal.TextChanged += new System.EventHandler(this.txtPSCVal_TextChanged);
            // 
            // txtPSCinfo
            // 
            this.txtPSCinfo.Location = new System.Drawing.Point(59, 23);
            this.txtPSCinfo.Name = "txtPSCinfo";
            this.txtPSCinfo.ReadOnly = true;
            this.txtPSCinfo.Size = new System.Drawing.Size(149, 20);
            this.txtPSCinfo.TabIndex = 1;
            // 
            // lstPSC
            // 
            this.lstPSC.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.name,
            this.columnHeader1});
            this.lstPSC.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstPSC.Location = new System.Drawing.Point(6, 49);
            this.lstPSC.MultiSelect = false;
            this.lstPSC.Name = "lstPSC";
            this.lstPSC.Size = new System.Drawing.Size(423, 251);
            this.lstPSC.TabIndex = 1;
            this.lstPSC.TileSize = new System.Drawing.Size(168, 50);
            this.lstPSC.UseCompatibleStateImageBehavior = false;
            this.lstPSC.View = System.Windows.Forms.View.Tile;
            this.lstPSC.SelectedIndexChanged += new System.EventHandler(this.lstPSC_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.cbEva);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.cbUlt2);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.cbUlt1);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.cbSuper4);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.cbSuper3);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.cbSuper2);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.cbSuper1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(435, 342);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Skills";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(137, 266);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(161, 23);
            this.button3.TabIndex = 16;
            this.button3.Text = "Save Skill Changes";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(237, 183);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 13);
            this.label19.TabIndex = 15;
            this.label19.Text = "Evasive #1";
            // 
            // cbEva
            // 
            this.cbEva.FormattingEnabled = true;
            this.cbEva.Location = new System.Drawing.Point(240, 199);
            this.cbEva.Name = "cbEva";
            this.cbEva.Size = new System.Drawing.Size(168, 21);
            this.cbEva.TabIndex = 14;
            this.cbEva.SelectedIndexChanged += new System.EventHandler(this.cbEva_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(237, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(61, 13);
            this.label21.TabIndex = 11;
            this.label21.Text = "Ultimate #2";
            // 
            // cbUlt2
            // 
            this.cbUlt2.FormattingEnabled = true;
            this.cbUlt2.Location = new System.Drawing.Point(240, 109);
            this.cbUlt2.Name = "cbUlt2";
            this.cbUlt2.Size = new System.Drawing.Size(168, 21);
            this.cbUlt2.TabIndex = 10;
            this.cbUlt2.SelectedIndexChanged += new System.EventHandler(this.cbUlt2_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(237, 48);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 13);
            this.label22.TabIndex = 9;
            this.label22.Text = "Ultimate #1";
            // 
            // cbUlt1
            // 
            this.cbUlt1.FormattingEnabled = true;
            this.cbUlt1.Location = new System.Drawing.Point(240, 64);
            this.cbUlt1.Name = "cbUlt1";
            this.cbUlt1.Size = new System.Drawing.Size(168, 21);
            this.cbUlt1.TabIndex = 8;
            this.cbUlt1.SelectedIndexChanged += new System.EventHandler(this.cbUlt1_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(25, 183);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Super #4";
            // 
            // cbSuper4
            // 
            this.cbSuper4.FormattingEnabled = true;
            this.cbSuper4.Location = new System.Drawing.Point(28, 199);
            this.cbSuper4.Name = "cbSuper4";
            this.cbSuper4.Size = new System.Drawing.Size(168, 21);
            this.cbSuper4.TabIndex = 6;
            this.cbSuper4.SelectedIndexChanged += new System.EventHandler(this.cbSuper4_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 137);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Super #3";
            // 
            // cbSuper3
            // 
            this.cbSuper3.FormattingEnabled = true;
            this.cbSuper3.Location = new System.Drawing.Point(28, 153);
            this.cbSuper3.Name = "cbSuper3";
            this.cbSuper3.Size = new System.Drawing.Size(168, 21);
            this.cbSuper3.TabIndex = 4;
            this.cbSuper3.SelectedIndexChanged += new System.EventHandler(this.cbSuper3_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(25, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Super #2";
            // 
            // cbSuper2
            // 
            this.cbSuper2.FormattingEnabled = true;
            this.cbSuper2.Location = new System.Drawing.Point(28, 109);
            this.cbSuper2.Name = "cbSuper2";
            this.cbSuper2.Size = new System.Drawing.Size(168, 21);
            this.cbSuper2.TabIndex = 2;
            this.cbSuper2.SelectedIndexChanged += new System.EventHandler(this.cbSuper2_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Super #1";
            // 
            // cbSuper1
            // 
            this.cbSuper1.FormattingEnabled = true;
            this.cbSuper1.Location = new System.Drawing.Point(28, 64);
            this.cbSuper1.Name = "cbSuper1";
            this.cbSuper1.Size = new System.Drawing.Size(168, 21);
            this.cbSuper1.TabIndex = 0;
            this.cbSuper1.SelectedIndexChanged += new System.EventHandler(this.cbSuper1_SelectedIndexChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.txtCSO4);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.txtCSO3);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.txtCSO2);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.txtCSO1);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.txtCMS7);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.txtCMS6);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.txtCMS5);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.txtCMS4);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.txtCMS3);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.txtCMS2);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.txtCMS1);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(435, 342);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "CMS/CSO";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(240, 263);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(174, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "Save CMS Changes";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(240, 302);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(174, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Save CSO Change";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtCSO4
            // 
            this.txtCSO4.Location = new System.Drawing.Point(240, 177);
            this.txtCSO4.Name = "txtCSO4";
            this.txtCSO4.Size = new System.Drawing.Size(174, 20);
            this.txtCSO4.TabIndex = 23;
            this.txtCSO4.TextChanged += new System.EventHandler(this.txtCSO4_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(237, 161);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(19, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "4?";
            // 
            // txtCSO3
            // 
            this.txtCSO3.Location = new System.Drawing.Point(240, 134);
            this.txtCSO3.Name = "txtCSO3";
            this.txtCSO3.Size = new System.Drawing.Size(174, 20);
            this.txtCSO3.TabIndex = 21;
            this.txtCSO3.TextChanged += new System.EventHandler(this.txtCSO3_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(237, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(19, 13);
            this.label14.TabIndex = 20;
            this.label14.Text = "3?";
            // 
            // txtCSO2
            // 
            this.txtCSO2.Location = new System.Drawing.Point(240, 95);
            this.txtCSO2.Name = "txtCSO2";
            this.txtCSO2.Size = new System.Drawing.Size(174, 20);
            this.txtCSO2.TabIndex = 19;
            this.txtCSO2.TextChanged += new System.EventHandler(this.txtCSO2_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(237, 79);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(19, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "2?";
            // 
            // txtCSO1
            // 
            this.txtCSO1.Location = new System.Drawing.Point(240, 52);
            this.txtCSO1.Name = "txtCSO1";
            this.txtCSO1.Size = new System.Drawing.Size(174, 20);
            this.txtCSO1.TabIndex = 17;
            this.txtCSO1.TextChanged += new System.EventHandler(this.txtCSO1_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(237, 36);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "1?";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(237, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 13);
            this.label17.TabIndex = 15;
            this.label17.Text = "CSO";
            // 
            // txtCMS7
            // 
            this.txtCMS7.Location = new System.Drawing.Point(19, 305);
            this.txtCMS7.Name = "txtCMS7";
            this.txtCMS7.Size = new System.Drawing.Size(174, 20);
            this.txtCMS7.TabIndex = 14;
            this.txtCMS7.TextChanged += new System.EventHandler(this.txtCMS7_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 289);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "cam.ean";
            // 
            // txtCMS6
            // 
            this.txtCMS6.Location = new System.Drawing.Point(19, 263);
            this.txtCMS6.Name = "txtCMS6";
            this.txtCMS6.Size = new System.Drawing.Size(174, 20);
            this.txtCMS6.TabIndex = 12;
            this.txtCMS6.TextChanged += new System.EventHandler(this.txtCMS6_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 247);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Player bac";
            // 
            // txtCMS5
            // 
            this.txtCMS5.Location = new System.Drawing.Point(19, 220);
            this.txtCMS5.Name = "txtCMS5";
            this.txtCMS5.Size = new System.Drawing.Size(174, 20);
            this.txtCMS5.TabIndex = 10;
            this.txtCMS5.TextChanged += new System.EventHandler(this.txtCMS5_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 204);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Player bcm";
            // 
            // txtCMS4
            // 
            this.txtCMS4.Location = new System.Drawing.Point(19, 177);
            this.txtCMS4.Name = "txtCMS4";
            this.txtCMS4.Size = new System.Drawing.Size(174, 20);
            this.txtCMS4.TabIndex = 8;
            this.txtCMS4.TextChanged += new System.EventHandler(this.txtCMS4_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Skill Animation";
            // 
            // txtCMS3
            // 
            this.txtCMS3.Location = new System.Drawing.Point(19, 134);
            this.txtCMS3.Name = "txtCMS3";
            this.txtCMS3.Size = new System.Drawing.Size(174, 20);
            this.txtCMS3.TabIndex = 6;
            this.txtCMS3.TextChanged += new System.EventHandler(this.txtCMS3_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "fce.ean";
            // 
            // txtCMS2
            // 
            this.txtCMS2.Location = new System.Drawing.Point(19, 95);
            this.txtCMS2.Name = "txtCMS2";
            this.txtCMS2.Size = new System.Drawing.Size(174, 20);
            this.txtCMS2.TabIndex = 4;
            this.txtCMS2.TextChanged += new System.EventHandler(this.txtCMS2_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "ean";
            // 
            // txtCMS1
            // 
            this.txtCMS1.Location = new System.Drawing.Point(19, 52);
            this.txtCMS1.Name = "txtCMS1";
            this.txtCMS1.Size = new System.Drawing.Size(174, 20);
            this.txtCMS1.TabIndex = 2;
            this.txtCMS1.TextChanged += new System.EventHandler(this.txtCMS1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "character";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "CMS";
            // 
            // cbCharacter
            // 
            this.cbCharacter.FormattingEnabled = true;
            this.cbCharacter.Location = new System.Drawing.Point(82, 12);
            this.cbCharacter.Name = "cbCharacter";
            this.cbCharacter.Size = new System.Drawing.Size(140, 21);
            this.cbCharacter.TabIndex = 1;
            this.cbCharacter.SelectedIndexChanged += new System.EventHandler(this.cbCharacter_SelectedIndexChanged);
            // 
            // cbCostumes
            // 
            this.cbCostumes.FormattingEnabled = true;
            this.cbCostumes.Location = new System.Drawing.Point(307, 12);
            this.cbCostumes.Name = "cbCostumes";
            this.cbCostumes.Size = new System.Drawing.Size(144, 21);
            this.cbCostumes.TabIndex = 2;
            this.cbCostumes.SelectedIndexChanged += new System.EventHandler(this.cbCostumes_SelectedIndexChanged);
            // 
            // lblChar
            // 
            this.lblChar.AutoSize = true;
            this.lblChar.Location = new System.Drawing.Point(23, 15);
            this.lblChar.Name = "lblChar";
            this.lblChar.Size = new System.Drawing.Size(53, 13);
            this.lblChar.TabIndex = 3;
            this.lblChar.Text = "Character";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(253, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Costume";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 419);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblChar);
            this.Controls.Add(this.cbCostumes);
            this.Controls.Add(this.cbCharacter);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Char Editor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ComboBox cbCharacter;
        private System.Windows.Forms.ComboBox cbCostumes;
        private System.Windows.Forms.Label lblChar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cbEva;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cbUlt2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cbUlt1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cbSuper4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbSuper3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbSuper2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbSuper1;
        private System.Windows.Forms.TextBox txtCSO4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCSO3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCSO2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtCSO1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtCMS7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCMS6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCMS5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCMS4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCMS3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCMS2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCMS1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cbZSoul;
        private System.Windows.Forms.TextBox txtPSCVal;
        private System.Windows.Forms.TextBox txtPSCinfo;
        private System.Windows.Forms.ListView lstPSC;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader columnHeader1;
    }
}

